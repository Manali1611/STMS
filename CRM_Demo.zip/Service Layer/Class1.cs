﻿using System;

namespace Service_Layer
{
    public class Class1
    {
    }
}
